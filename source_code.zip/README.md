There's a 3 files that you will need: 
1. models.py - just a model shcema with a few functions to update app and pricing
2. main.py - populates apps and reviews
3. reviews.py - populates review for each app 